# YARP — version used for this work (snapshot 2026-05-22)

## How to use

This package replaces the upstream `yarp/`. Either:

(a) Point Python at this directory directly:
```python
import sys
sys.path.insert(0, "/path/to/yarp_2026-05-22")
import yarp as yp
```

(b) Or install it as a drop-in over an existing yarp checkout:
```bash
cp -r yarp/* /path/to/your/yarp_install/
```

The package has no `setup.py`/`pyproject.toml` — it is a flat module tree
matching the upstream layout.

## Reproducing the published OS data

With this YARP and the IRC trajectories from the dataset:
```python
from yarp import yarpecule
y = yarpecule(("path/to/finished_first.xyz", reaction_charge), canon=False)
bem = y.bond_mats[0]
# For each atom i: e = int(bem[i,i]); OS = el_valence[element] - e
```

The five scripts that drive this in the production pipeline live alongside
this folder under `scripts/os/`:

| Script | Purpose |
|---|---|
| `regen_frame_jsons.py` | Per-archive BEM regen for `.tar.zst` archives |
| `regen_zip_archive.py` | Per-archive BEM regen for `.zip` archives in `doi_zips_slim/` |
| `extract_oxidation_states.py` | Reads frame JSONs, writes the per-reaction OS CSV |
| `build_tm_os_matrix.py` | Dedups and aggregates the OS CSV → per-metal × OS bin matrix |
| `draw_tm_os_radial_dials_fullcircle.py` | Renders the radial-dial OS plot |
