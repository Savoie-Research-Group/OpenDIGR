import yarp as yp
import rdkit 
from rdkit import Chem
from PIL import Image,ImageDraw
from rdkit.Chem import Descriptors
from copy import deepcopy
import pandas as pd 
from IPython.display import display
from rdkit.Chem import AllChem,rdchem,BondType,MolFromSmiles,Draw,Atom,AddHs,HybridizationType,MolToSmiles
from yarp.taffi_functions import table_generator,return_rings,adjmat_to_adjlist,canon_order
from yarp.properties import el_to_an,an_to_el,el_mass
from yarp.find_lewis import find_lewis,return_formals,return_n_e_accept,return_n_e_donate,return_formals,return_connections,return_bo_dict
from yarp.hashes import atom_hash,yarpecule_hash
from yarp.input_parsers import xyz_parse,xyz_q_parse,xyz_from_smiles,mol_parse
from yarp.misc import merge_arrays, prepare_list
from yarp.yarpecule import draw_yarpecules
import numpy as np 
import networkx as nx

def frag_rxn_single_bonds(yarpecules,label_ind=False):
    """
    Wrapper for getting the fragmentation reaction smiles from yarpecules using rdkit. This is only for single bond breaks. 
    We will code other fragmentation things for other kinds of bonds breaking. 
    The best way to ensure consistency in atom-mapping for EGAT is to set label_ind=True. That way we can load the atom-mapping into the yarpecule from the SMILES. 

    Parameters
    ----------
    yarpecules: list
                list of yarpecule objects. 

    label_ind: bool, default=False
               Controls whether the atom indices are drawn in the structure. Default is no labels. 

    
    Returns
    -------
    None
    """
    # Handles the singular use-case
    yarpecules = prepare_list(yarpecules)
    
    # Return if there is nothing to draw
    if len(yarpecules) == 0:
        return

    # Keep rdkit happy
    elif len(yarpecules) > 250:
        print(f"Skipping draw_yarpecules() call. {len(yarpecules)} is too many for rdkit to render")
        return

    # Initialize the preferred lone electron dictionary the first time this function is called
    if not hasattr(draw_yarpecules, "bond_to_type"):
        draw_yarpecules.bond_to_type = { 1:BondType.SINGLE, 2:BondType.DOUBLE, 3:BondType.TRIPLE, 4:BondType.QUADRUPLE, 5:BondType.QUINTUPLE, 6:BondType.HEXTUPLE }

    # loop over yarpecules, create an rdkit mol for each, then plot on a grid 
    mols = []
    #smis = []
    for count_i,i in enumerate(yarpecules):                
        # throwaway molecule
        mol = MolFromSmiles("C")
        mol = rdchem.RWMol(mol)
        mol.RemoveAtom(0)
        # add atoms
        [ mol.AddAtom(Atom(el_to_an[_])) for _ in i.elements ]
        # add bonds
        for count_j,j in enumerate(i.bond_mats[0]):
            for count_k,k in enumerate(j):
                if count_k<count_j:
                    if k == 0:
                        continue
                    else:
                        mol.AddBond(count_j,count_k,draw_yarpecules.bond_to_type[k])
                else:
                    break
        # set explicit H-atoms and formals
        fc = return_formals(i.bond_mats[0],[ _.lower() for _ in i.elements ])
        for count_j,j in enumerate(i.bond_mats[0]):
            atom = mol.GetAtomWithIdx(count_j)
            mol.GetAtomWithIdx(count_j).SetNumExplicitHs(0)
            mol.GetAtomWithIdx(count_j).SetFormalCharge(int(fc[count_j]))
            mol.GetAtomWithIdx(count_j).SetNumRadicalElectrons(int(j[count_j]%2))
            try:
                mol.GetAtomWithIdx(count_j).UpdatePropertyCache()
            except:
                print(f"problem is with atom {count_j} {fc[count_j]} {i.bond_mat_scores[0]}:\n{i.elements}\n{i.adj_mat}\n{i.bond_mats[0]}")


        # generate coordinates
        AllChem.Compute2DCoords(mol)

        # assign index label
        if label_ind:
            # Iterate over the atoms
            for i, atom in enumerate(mol.GetAtoms()):
                # For each atom, set the property "molAtomMapNumber" to the index of a atom 
                atom.SetProp("molAtomMapNumber", str(atom.GetIdx()+1))
        #smis += [MolToSmiles(mol)]

        #Make a copy of the mol file 
        molcopy = deepcopy(mol)
        radloc = []
        #for the mol file find the location of the radical electrons
        for atoms in mol.GetAtoms():
            if atoms.GetNumRadicalElectrons() > 0:
                if label_ind:
                    radloc += [atoms.GetAtomMapNum()]
                else:
                    radloc += [atoms.GetIdx()]
        #Works for Alkanes and single bond ones: For the location of the radical, change one of them to a ion.
        # Test for Rings, multi bonds, and Aromatics.
        if label_ind:
            mol.GetAtomWithIdx(radloc[0]-1).SetNumRadicalElectrons(0)
            mol.GetAtomWithIdx(radloc[0]-1).SetFormalCharge(1)

            molcopy.GetAtomWithIdx(radloc[1]-1).SetNumRadicalElectrons(0)
            molcopy.GetAtomWithIdx(radloc[1]-1).SetFormalCharge(1)
        else:
            mol.GetAtomWithIdx(radloc[0]).SetNumRadicalElectrons(0)
            mol.GetAtomWithIdx(radloc[0]).SetFormalCharge(1)

            molcopy.GetAtomWithIdx(radloc[1]).SetNumRadicalElectrons(0)
            molcopy.GetAtomWithIdx(radloc[1]).SetFormalCharge(1)

        mols += [mol,molcopy]    
    # save the molecule
    return mols



def RemoveMapping(mol):
    """
    Remove the Atom mapping in the mol file. 
    Parameters
    ----------
    mol: RDKit mol object
        
    Returns
    -------
    mol: RDKit mol object
    """
    [a.SetAtomMapNum(0) for a in mol.GetAtoms()]
    return mol



def homolytic_cleavage(bond_mat,i,j,rads):
    """
    Gets a homolytic cleavage of the atoms based on the bond matrix. 
    
    Parameters
    ----------
    bond_mat: np.ndarray or list
            Bond Electron Matrix of the Reactant.
    i,j: int
            The locations of the atoms that you want to remove a single bond from.  
    rads: list
            list of radical electron count of each atom

    Returns
    -------
    bond_mat: np.ndarray or list
            Bond Electron Matrix of the Reactant.
    rads: list
            list of radical electron count of each atom
    """
    bond_mat_copy = deepcopy(bond_mat)
    rads_copy = deepcopy(rads)
    if i != j:
        if bond_mat_copy[i][j] == 1:
            bond_mat_copy[i][j] = bond_mat_copy[i][j] - 1
            bond_mat_copy[j][i] = bond_mat_copy[j][i] - 1
            bond_mat_copy[i][i] += 1
            bond_mat_copy[j][j] += 1
            rads_copy[i] += 1
            rads_copy[j] += 1
            return bond_mat_copy,rads_copy
        elif bond_mat_copy[i][j] == 2:
            bond_mat_copy[i][j] = bond_mat_copy[i][j] - 2
            bond_mat_copy[j][i] = bond_mat_copy[j][i] - 2
            bond_mat_copy[i][i] += 2
            bond_mat_copy[j][j] += 2
            rads_copy[i] += 2
            rads_copy[j] += 2
            return bond_mat_copy,rads_copy
        else:
            print(bond_mat_copy[i][j])
            return 'This is not a single bond'
    else:
        return 'You are doing a cleavage on the same atom'
   

def heterolytic_cleavage(bond_mat,i,j,fc):
    """
    Gets a heterolytic cleavage of the atoms based on the bond matrix. 
    Parameters
    ----------
    bond_mat: np.ndarray or list
            Bond Electron Matrix of the Reactant.
    i,j: int
            The locations of the atoms that you want to remove a single bond from.  
    rads: list
            list of radical electron count of each atom
    Returns
    -------
    bond_mat: np.ndarray or list
            Bond Electron Matrix of the Reactant.
    rads: list
            list of radical electron count of each atom
    """
    bond_mat_copy = deepcopy(bond_mat)
    fc_copy1 = deepcopy(fc)
    fc_copy2 = deepcopy(fc)
    
    if i != j:
        if bond_mat_copy[i][j] == 1:
            bond_mat_copy[i][j] = bond_mat_copy[i][j] - 1
            bond_mat_copy[j][i] = bond_mat_copy[j][i] - 1
            bond_mat_copy[i][i] += 1
            bond_mat_copy[j][j] += 1
            
            fc_copy1[i] += 1
            fc_copy1[j] = fc_copy1[j] - 1
            
            fc_copy2[j] += 1
            fc_copy2[i] = fc_copy2[j] - 1
            
            
            return bond_mat_copy,fc_copy1,fc_copy2
        elif bond_mat_copy[i][j] == 2:
            bond_mat_copy[i][j] = bond_mat_copy[i][j] - 2
            bond_mat_copy[j][i] = bond_mat_copy[j][i] - 2
            bond_mat_copy[i][i] += 2
            bond_mat_copy[j][j] += 2
            fc_copy1[i] += 2
            fc_copy1[j] = fc_copy1[j] - 2
            
            fc_copy2[j] += 2
            fc_copy2[i] = fc_copy2[j] - 2
            return bond_mat_copy,fc_copy1,fc_copy2
        else:
            return 'This is not a single bond'
    else:
        return 'You are doing a cleavage on the same atom'

def getradicals(bond_mat,initial = True):
    """
    Gets a radical electron count of each atom based on the bond matrix. 
    We do not count di-radicals (atoms with two radical electrons - that's just a lone pair) as we are trying to tag possible carbocations. 

    Parameters
    ----------
    bond_mat: np.ndarray or list
            Bond Electron Matrix of the Reactant.
    
    initial: bool
            check if it already has it or not.

    
    Returns
    -------
    rads: list
            list of radical electron count of each atom
    """
    rads = []
    if not isinstance(bond_mat,np.ndarray): bond_mat = np.array(bond_mat)
    for i in range(bond_mat.shape[0]):
        if initial:
            rads += [bond_mat[i][i]%2]
        else:
            rads += [bond_mat[i][i]]
    return rads


def create_mol(elements, bond_matrix, formal_charges, radical_electrons,atom_mapping=None):
    """
    Gets an RDKit mol file based on the elements, bond electron matrix, formal charge, and radical electrons. 
    
    Parameters
    ----------
    elements: list
            list of elements of each atom

    bond_mat: np.ndarray or list
            Bond Electron Matrix of the Reactant.

    formal_charges: list
            list of formal charge of each atom
    
    rads: list
            list of radical electrons of each atom

    Returns
    -------
    mol: RDKit mol object
            list of radical electron count of each atom
    smi: Smiles string
            SMILES string of the new mol object
    """

    bond_to_type = {1:BondType.SINGLE, 2:BondType.DOUBLE, 3:BondType.TRIPLE, 4:BondType.QUADRUPLE, 5:BondType.QUINTUPLE, 6:BondType.HEXTUPLE }

    # Create an RDKit Mol object
    mol = Chem.RWMol()
    

    # Add atoms to the molecule
    for element in elements:
        atom = Chem.Atom(element.upper())
        mol.AddAtom(atom)
    
    # Add bonds to the molecule
    num_atoms = len(elements)
    for i in range(num_atoms):
        for j in range(i + 1, num_atoms):
            bond_order = bond_matrix[i][j]
            if bond_order > 0:
                mol.AddBond(i, j, order=bond_to_type[bond_order])

    # Set formal charges
    for i, charge in enumerate(formal_charges):
        mol.GetAtomWithIdx(i).SetFormalCharge(int(charge))

    # Set radical electrons
    for i, radicals in enumerate(radical_electrons):
        mol.GetAtomWithIdx(i).SetNumRadicalElectrons(int(radicals))
    
    if atom_mapping is not None:
        for i, mapnum in enumerate(atom_mapping):
            mol.GetAtomWithIdx(i).SetAtomMapNum(int(mapnum))

    return mol



def to_smi(yarpecules,label_ind=False):
    """
    Wrapper for smiles of yarpecules using rdkit.

    Parameters
    ----------
    yarpecules: list
                list of yarpecule objects. 

    name: str
          filename for the save (should end in an image format supported by rdkit like \*.pdf).

    label_ind: bool, default=False
               Controls whether the atom indices are drawn in the structure. Default is no labels. 

    mol_labels: list
                This option can be used to display a label beneath each molecule (e.g., a score). 

    Returns
    -------
    None
    """
    # Handles the singular use-case
    yarpecules = prepare_list(yarpecules)
    
    # Return if there is nothing to draw
    if len(yarpecules) == 0:
        return

    # Keep rdkit happy
    elif len(yarpecules) > 250:
        print(f"Skipping draw_yarpecules() call. {len(yarpecules)} is too many for rdkit to render")
        return

    # Initialize the preferred lone electron dictionary the first time this function is called
    if not hasattr(draw_yarpecules, "bond_to_type"):
        draw_yarpecules.bond_to_type = { 1:BondType.SINGLE, 2:BondType.DOUBLE, 3:BondType.TRIPLE, 4:BondType.QUADRUPLE, 5:BondType.QUINTUPLE, 6:BondType.HEXTUPLE }

    # loop over yarpecules, create an rdkit mol for each, then plot on a grid 
    mols = []
    #smis = []
    for count_i,i in enumerate(yarpecules):                
        # throwaway molecule
        mol = MolFromSmiles("C")
        mol = rdchem.RWMol(mol)
        mol.RemoveAtom(0)
        # add atoms
        [ mol.AddAtom(Atom(el_to_an[_])) for _ in i.elements ]
        # add bonds
        for count_j,j in enumerate(i.bond_mats[0]):
            for count_k,k in enumerate(j):
                if count_k<count_j:
                    if k == 0:
                        continue
                    else:
                        mol.AddBond(count_j,count_k,draw_yarpecules.bond_to_type[k])
                else:
                    break
        # set explicit H-atoms and formals
        fc = return_formals(i.bond_mats[0],[ _.lower() for _ in i.elements ])
        for count_j,j in enumerate(i.bond_mats[0]):
            atom = mol.GetAtomWithIdx(count_j)
            mol.GetAtomWithIdx(count_j).SetNumExplicitHs(0)
            mol.GetAtomWithIdx(count_j).SetFormalCharge(int(fc[count_j]))
            mol.GetAtomWithIdx(count_j).SetNumRadicalElectrons(int(j[count_j]%2))
            try:
                mol.GetAtomWithIdx(count_j).UpdatePropertyCache()
            except:
                print(f"problem is with atom {count_j} {fc[count_j]} {i.bond_mat_scores[0]}:\n{i.elements}\n{i.adj_mat}\n{i.bond_mats[0]}")

        # generate coordinates
        AllChem.Compute2DCoords(mol)

        # assign index label
        if label_ind:
            # Iterate over the atoms
            for i, atom in enumerate(mol.GetAtoms()):
                # For each atom, set the property "molAtomMapNumber" to the index of a atom 
                atom.SetProp("molAtomMapNumber", str(atom.GetIdx()+1))
        #smis += [MolToSmiles(mol)]
        mols += [MolToSmiles(mol)]    
    # save the molecule
    return mols

def to_mol(yarpecules,label_ind=False):
    """
    Wrapper for smiles of yarpecules using rdkit.

    Parameters
    ----------
    yarpecules: list
                list of yarpecule objects. 

    name: str
          filename for the save (should end in an image format supported by rdkit like \*.pdf).

    label_ind: bool, default=False
               Controls whether the atom indices are drawn in the structure. Default is no labels. 

    mol_labels: list
                This option can be used to display a label beneath each molecule (e.g., a score). 

    Returns
    -------
    None
    """
    # Handles the singular use-case
    yarpecules = prepare_list(yarpecules)
    
    # Return if there is nothing to draw
    if len(yarpecules) == 0:
        return

    # Keep rdkit happy
    elif len(yarpecules) > 250:
        print(f"Skipping draw_yarpecules() call. {len(yarpecules)} is too many for rdkit to render")
        return

    # Initialize the preferred lone electron dictionary the first time this function is called
    if not hasattr(draw_yarpecules, "bond_to_type"):
        draw_yarpecules.bond_to_type = { 1:BondType.SINGLE, 2:BondType.DOUBLE, 3:BondType.TRIPLE, 4:BondType.QUADRUPLE, 5:BondType.QUINTUPLE, 6:BondType.HEXTUPLE }

    # loop over yarpecules, create an rdkit mol for each, then plot on a grid 
    mols = []
    #smis = []
    for count_i,i in enumerate(yarpecules):                
        # throwaway molecule
        mol = MolFromSmiles("C")
        mol = rdchem.RWMol(mol)
        mol.RemoveAtom(0)
        # add atoms
        [ mol.AddAtom(Atom(el_to_an[_])) for _ in i.elements ]
        # add bonds
        for count_j,j in enumerate(i.bond_mats[0]):
            for count_k,k in enumerate(j):
                if count_k<count_j:
                    if k == 0:
                        continue
                    else:
                        mol.AddBond(count_j,count_k,draw_yarpecules.bond_to_type[k])
                else:
                    break
        # set explicit H-atoms and formals
        fc = return_formals(i.bond_mats[0],[ _.lower() for _ in i.elements ])
        for count_j,j in enumerate(i.bond_mats[0]):
            atom = mol.GetAtomWithIdx(count_j)
            mol.GetAtomWithIdx(count_j).SetNumExplicitHs(0)
            mol.GetAtomWithIdx(count_j).SetFormalCharge(int(fc[count_j]))
            mol.GetAtomWithIdx(count_j).SetNumRadicalElectrons(int(j[count_j]%2))
            try:
                mol.GetAtomWithIdx(count_j).UpdatePropertyCache()
            except:
                print(f"problem is with atom {count_j} {fc[count_j]} {i.bond_mat_scores[0]}:\n{i.elements}\n{i.adj_mat}\n{i.bond_mats[0]}")

        # generate coordinates
        AllChem.Compute2DCoords(mol)

        # assign index label
        if label_ind:
            # Iterate over the atoms
            for i, atom in enumerate(mol.GetAtoms()):
                # For each atom, set the property "molAtomMapNumber" to the index of a atom 
                atom.SetProp("molAtomMapNumber", str(atom.GetIdx()+1))
        #smis += [MolToSmiles(mol)]
        mols += [mol]    
    # save the molecule
    return mols

def CheckForLonePairs(bmat):
    """
    Function that checks if lone pairs are present in the Starting point.

    Parameters
    ----------
    bmat: np.array 
            Bond Matrix from yarpecule. 

    Returns
    -------
    lplocation: list
            Location of the lone pair.

    lpcount: int
            Number of lone pairs..
    """

    # Iterate at all atoms
    lpcount = 0
    lplocation = []
    for i in range(bmat.shape[0]):
        if bmat[i][i] > 0 and bmat[i][i]%2 == 0: 
            lpcount += 1
            lplocation += [i]
    if lpcount >= 1:
        return lplocation,lpcount
    else:
        return None,lpcount
    
def CheckForMultiBonds(bmat):

    """
    Function that checks if pi bonding are present in the Starting point.

    Parameters
    ----------
    bmat: np.array 
            Bond Matrix from yarpecule. 

    Returns
    -------
    location: list
            Location of the lone pair.

    count: int
            Number of lone pairs..
    """
    # Iterate at all atoms
    count = 0
    location = []
    for i in range(bmat.shape[0]):
        for j in range(bmat.shape[0]):
            if i > j:
                if bmat[i][j] > 1:
                    count += 1
                    location += [(i,j)]
    if count >= 1:
        return location,count
    else:
        return None,count


def GetMolecularIon(cule):
    """
    Function that gets a lit of molecular ions. Works for Pi bonded and lone pair containing molecules. 
    Parameters
    ----------
    bmat: np.array 
            Bond Matrix from yarpecule. 

    Returns
    -------
    lplocation: list
            Location of the lone pair.

    lpcount: int
            Number of lone pairs..
    """
    #Iterate through every yarpecule
    ionmols = []
    hashes = []
    #Check if there are lone pairs
    elements = cule.elements
    formal_charges = cule.fc
    try:
        mapping = cule.amapping
    except:
        pass

    for bmat in cule.bond_mats:
        lplocation,lpcount = CheckForLonePairs(bmat)
        multilocation,multicount = CheckForMultiBonds(bmat)
        rads = getradicals(bmat)
        #If there are lone pairs remove an electron
        if lpcount > 0:
            if multicount == 0:
                for lploc in lplocation:
                    tmp = dict()
                    tmp['fc'] = deepcopy(formal_charges)
                    tmp['rads'] = deepcopy(rads)
                    tmp['bmat'] = deepcopy(bmat)
                    tmp['bmat'][lploc][lploc] = tmp['bmat'][lploc][lploc] - 1
                    tmp['fc'][lploc] += 1
                    tmp['rads'][lploc] += 1  
                    try:
                        product = create_mol(elements, tmp['bmat'],tmp['fc'],tmp['rads'],mapping)
                        hashe = Chem.MolToSmiles(create_mol(elements, tmp['bmat'],tmp['fc'],tmp['rads']))
                        if hashe not in hashes:
                            ionmols += [product]
                            hashes += [hashe]
                    except:
                        try:
                            product = create_mol(elements, tmp['bmat'],tmp['fc'],tmp['rads'])
                            hashe = Chem.MolToSmiles(hashe)
                            if hashe not in hashes:
                                ionmols += [product]
                                hashes += [hashe]
                        except:
                            pass
            else:
                for lploc in lplocation:
                    tmp = dict()
                    tmp['fc'] = deepcopy(formal_charges)
                    tmp['rads'] = deepcopy(rads)
                    tmp['bmat'] = deepcopy(bmat)
                    tmp['bmat'][lploc][lploc] = tmp['bmat'][lploc][lploc] - 1
                    tmp['fc'][lploc] += 1
                    tmp['rads'][lploc] += 1  
                    try:
                        product = create_mol(elements, tmp['bmat'],tmp['fc'],tmp['rads'],mapping)
                        hashe = Chem.MolToSmiles(create_mol(elements, tmp['bmat'],tmp['fc'],tmp['rads']))
                        if hashe not in hashes:
                            ionmols += [product]
                            hashes += [hashe]
                    except:
                        try:
                            product = create_mol(elements, tmp['bmat'],tmp['fc'],tmp['rads'])
                            hashe = Chem.MolToSmiles(hashe)
                            if hashe not in hashes:
                                ionmols += [product]
                                hashes += [hashe]
                        except:
                            pass
              
                for loc in multilocation:
                    tmp = dict()
                    tmp['fc'] = deepcopy(formal_charges)
                    tmp['rads'] = deepcopy(rads)
                    tmp['bmat'] = deepcopy(bmat)
                    tmp['bmat'][loc[0]][loc[1]] = tmp['bmat'][loc[0]][loc[1]] - 1
                    tmp['bmat'][loc[1]][loc[0]] = tmp['bmat'][loc[1]][loc[0]] - 1
                    tmp['fc'][loc[0]] += 1
                    tmp['rads'][loc[1]] += 1 
                    try:
                        product = create_mol(elements, tmp['bmat'],tmp['fc'],tmp['rads'],mapping)
                        hashe = Chem.MolToSmiles(create_mol(elements, tmp['bmat'],tmp['fc'],tmp['rads']))
                        if hashe not in hashes:
                            ionmols += [product]
                            hashes += [hashe]
                    except:
                        try:
                            product = create_mol(elements, tmp['bmat'],tmp['fc'],tmp['rads'])
                            hashe = Chem.MolToSmiles(hashe)
                            if hashe not in hashes:
                                ionmols += [product]
                                hashes += [hashe]
                        except:
                            pass
                    
                    tmp = dict()
                    tmp['fc'] = deepcopy(formal_charges)
                    tmp['rads'] = deepcopy(rads)
                    tmp['bmat'] = deepcopy(bmat)
                    tmp['bmat'][loc[0]][loc[1]] = tmp['bmat'][loc[0]][loc[1]] - 1
                    tmp['bmat'][loc[1]][loc[0]] = tmp['bmat'][loc[1]][loc[0]] - 1
                    tmp['fc'][loc[1]] += 1
                    tmp['rads'][loc[0]] += 1 
                    try:
                        product = create_mol(elements, tmp['bmat'],tmp['fc'],tmp['rads'],mapping)
                        hashe = Chem.MolToSmiles(create_mol(elements, tmp['bmat'],tmp['fc'],tmp['rads']))
                        if hashe not in hashes:
                            ionmols += [product]
                            hashes += [hashe]
                    except:
                        try:
                            product = create_mol(elements, tmp['bmat'],tmp['fc'],tmp['rads'])
                            hashe = Chem.MolToSmiles(hashe)
                            if hashe not in hashes:
                                ionmols += [product]
                                hashes += [hashe]
                        except:
                            pass
        else:
            if multicount>0:
                for loc in multilocation:
                    tmp = dict()
                    tmp['fc'] = deepcopy(formal_charges)
                    tmp['rads'] = deepcopy(rads)
                    tmp['bmat'] = deepcopy(bmat)
                    tmp['bmat'][loc[0]][loc[1]] = tmp['bmat'][loc[0]][loc[1]] - 1
                    tmp['bmat'][loc[1]][loc[0]] = tmp['bmat'][loc[1]][loc[0]] - 1
                    tmp['fc'][loc[0]] += 1
                    tmp['rads'][loc[1]] += 1 
                    try:
                        product = create_mol(elements, tmp['bmat'],tmp['fc'],tmp['rads'],mapping)
                        hashe = Chem.MolToSmiles(create_mol(elements, tmp['bmat'],tmp['fc'],tmp['rads']))
                        if hashe not in hashes:
                            ionmols += [product]
                            hashes += [hashe]
                    except:
                        try:
                            product = create_mol(elements, tmp['bmat'],tmp['fc'],tmp['rads'])
                            hashe = Chem.MolToSmiles(hashe)
                            if hashe not in hashes:
                                ionmols += [product]
                                hashes += [hashe]
                        except:
                            pass
                    
                    tmp = dict()
                    tmp['fc'] = deepcopy(formal_charges)
                    tmp['rads'] = deepcopy(rads)
                    tmp['bmat'] = deepcopy(bmat)
                    tmp['bmat'][loc[0]][loc[1]] = tmp['bmat'][loc[0]][loc[1]] - 1
                    tmp['bmat'][loc[1]][loc[0]] = tmp['bmat'][loc[1]][loc[0]] - 1
                    tmp['fc'][loc[1]] += 1
                    tmp['rads'][loc[0]] += 1 
                    try:
                        product = create_mol(elements, tmp['bmat'],tmp['fc'],tmp['rads'],mapping)
                        hashe = Chem.MolToSmiles(create_mol(elements, tmp['bmat'],tmp['fc'],tmp['rads']))
                        if hashe not in hashes:
                            ionmols += [product]
                            hashes += [hashe]
                    except:
                        try:
                            product = create_mol(elements, tmp['bmat'],tmp['fc'],tmp['rads'])
                            hashe = Chem.MolToSmiles(hashe)
                            if hashe not in hashes:
                                ionmols += [product]
                                hashes += [hashe]
                        except:
                            pass

            else:
                
                for i,sym in enumerate(elements): 
                    if sym != 'H':
                        tmp = dict()
                        tmp['fc'] = deepcopy(formal_charges)
                        tmp['rads'] = deepcopy(rads)
                        tmp['bmat'] = deepcopy(bmat)

                        tmp['rads'][i] += 1
                        tmp['fc'][i] += 1
                        try:
                            product = create_mol(elements, tmp['bmat'],tmp['fc'],tmp['rads'],mapping)
                            hashe = Chem.MolToSmiles(create_mol(elements, tmp['bmat'],tmp['fc'],tmp['rads']))
                            if hashe not in hashes:
                                ionmols += [product]
                                hashes += [hashe]
                        except:
                            try:
                                product = create_mol(elements, tmp['bmat'],tmp['fc'],tmp['rads'])
                                hashe = Chem.MolToSmiles(hashe)
                                if hashe not in hashes:
                                    ionmols += [product]
                                    hashes += [hashe]
                            except:
                                pass

                        

                    


            
    return ionmols  


def getcarbocationfromhash(hashe):
    comp = hashe.split('.')
    for _ in comp:
        if '+' in _: return _
        
def EditAtomMapping(mol,mapping):
    for i,atoms in enumerate(mol.GetAtoms()):
        atoms.SetAtomMapNum(mapping[i])
    if i < len(mapping)-1:
        return None
    else:
        return mol

        
def get_molecular_weight(smiles):
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        raise ValueError("Invalid SMILES string")

    molecular_weight = Descriptors.MolWt(mol)

    return molecular_weight


def SpitCarbocationInformation(bond_mat,fc):
    # Find connected components in the graph
    G = nx.from_numpy_matrix(bond_mat)
    subgraphs = list(nx.connected_components(G))
    
    #Check if each component has an ion
    for i,subgraph in enumerate(subgraphs):
        checkfc = 0
        for ind in subgraph:
            if fc[ind] > 0:
                checkfc += 1
        
        if checkfc > 0:
            return subgraph
        
def getradicalsfromsmiles(hashe):
    comp = hashe.split('.')
    iscat = []
    for _ in comp:
        if '+' in _: iscat += [True]
        else: iscat += [False]
    string = ''
    if len(iscat) > 1:
        for i in range(len(iscat)):
            if iscat[i] is not True:
                string += comp[i] + '.'
    return string[:-1]


def makebondbetweentworadicals(bmat,i,j,rads):
    bmat_copy = deepcopy(bmat)
    rads_copy = deepcopy(rads)
    
    
    if i != j:
        if bmat_copy[i][i] %2 == 1 and bmat_copy[j][j] %2 == 1:
                bmat_copy[i][j] += 1
                bmat_copy[j][i] += 1
                bmat_copy[i][i] = bmat_copy[i][i]-1
                bmat_copy[j][j] = bmat_copy[j][j]-1
                rads_copy[i] = rads_copy[i] - 1
                rads_copy[j] = rads_copy[j] - 1
                return bmat_copy,rads_copy
        