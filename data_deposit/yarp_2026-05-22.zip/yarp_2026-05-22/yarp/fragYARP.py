import yarp as yp
import rdkit 
from rdkit import Chem
from rdkit.Chem import Descriptors
from PIL import Image
from copy import deepcopy
from IPython.display import display
from rdkit.Chem import AllChem,rdchem,BondType,MolFromSmiles,Draw,Atom,AddHs,HybridizationType
from yarp.taffi_functions import table_generator,return_rings,adjmat_to_adjlist,canon_order
from yarp.properties import el_to_an,an_to_el,el_mass
from yarp.find_lewis import find_lewis,return_formals,return_n_e_accept,return_n_e_donate,return_formals,return_connections,return_bo_dict
from yarp.hashes import atom_hash,yarpecule_hash
from yarp.input_parsers import xyz_parse,xyz_q_parse,xyz_from_smiles,mol_parse
from yarp.misc import merge_arrays, prepare_list
from yarp.yarpecule import draw_yarpecules
from fragmentation import *
import numpy as np
import pandas as pd

### Code the Combinatorics on the Isotopes and get their Abundance w.r.t to original molecule. 
### Code the Code that saves the data into a reaction with the amu w.r.t to the isotope combinations.

class FragYARP:
    def __init__(self,smiles,iterations=None,tolerance=2):
        self.smiles = smiles
        #Atom map the smiles string
        self.InitializeMapping()

        # Get the Molecular Ions as a list RDKit mol files
        self.MolecularIon()
      
        self.data = dict()
        self.data['Carbocation'] = [Chem.MolToSmiles(_) for _ in self.molecularions]
        self.data['Radical'] = [''] * len(self.data['Carbocation'])
        self.data['Depth'] = [0] * len(self.data['Carbocation'])
        self.data['Reaction'] = [_ for _ in range(len(self.data['Carbocation']))]
        self.data['Reactant'] = [self.atom_mapped_smiles] * len(self.data['Carbocation'])
        self.data['Start'] = [self.atom_mapped_smiles] * len(self.data['Carbocation'])
        self.data['Hash'] = [Chem.MolToSmiles(RemoveMapping(_)) for _ in self.molecularions]
        self.data['Hash_Carbocation'] = [Chem.MolToSmiles(RemoveMapping(_)) for _ in self.molecularions]
        self.data['InChI_Carbocation'] = [Chem.MolToInchiKey(RemoveMapping(_)) for _ in self.molecularions]
        self.data['Step'] = ['Molecular Ion Formation'] * len(self.data['Carbocation'])
        



        self.data['BondMatrix'] = []
        self.data['FC'] = []
        self.data['Rads'] = []


        for _ in self.molecularions:
            cule = yp.yarpecule(Chem.MolToSmiles(_),canon=False,mapping=True)
            self.data['BondMatrix'] += [cule.bond_mats[0]]
            self.data['FC'] += [cule.fc]
            self.data['Rads'] += [getradicals(cule.bond_mats[0],False)]

        

        self.data  = pd.DataFrame(self.data)

        #Check if it's an alkane
        earray = np.array(self.molecule.elements)

        # Get The first depth
        if len(np.unique(earray)) == 1 and np.unique(earray)[0] == 'C':
            df = self.Depth1Alkane()
            df = pd.DataFrame(df)
            self.data = pd.concat([self.data,df])
        else:
            df = self.HomolyticCleavageLayer()
            df = pd.DataFrame(df)
            df['Step'] = 'Carbocation Homolytic Cleavage'
            self.data = pd.concat([self.data,df])
            df = self.HeterocyclicCleavageLayer()
            df = pd.DataFrame(df)
            df['Step'] = 'Carbocation Heterocyclic Cleavage'
            self.data = pd.concat([self.data,df])
        
        # Get the unique Carbocations from the 
        self.data = self.data.groupby('Hash_Carbocation').min().reset_index()

        if iterations != None:
            for _ in range(2,iterations):
                df = self.HomolyticCleavageLayer(_)
                if df['Carbocation'] != []:
                    df = pd.DataFrame(df)
                    df['Step'] = 'Carbocation Homolytic Cleavage'
                    self.data = pd.concat([self.data,df])

                df = self.HeterocyclicCleavageLayer(_)
                if df['Carbocation'] != []:
                    df = pd.DataFrame(df)
                    df['Step'] = 'Carbocation Heterocyclic Cleavage'
                    self.data = pd.concat([self.data,df])

                df = self.RingFormation(_)
                if df['Carbocation'] != []:
                    df = pd.DataFrame(df)
                    df['Step'] = 'Ring Formation'
                    self.data = pd.concat([self.data,df])

                df = self.CombineRadicaltoCarbocation(_)
                if df['Carbocation'] != []:
                    df = pd.DataFrame(df)
                    df['Step'] = 'Radical Carbocation Recombination'
                    self.data = pd.concat([self.data,df])
        else:
            delta = 10000
            depth = 2
            oldval = 0
            self.globaldata = dict()
            self.globaldata['uniques'] = []
            self.globaldata['reactions'] = []
            while delta > tolerance:
                df = self.HomolyticCleavageLayer(depth)
                if df['Carbocation'] != []:
                    df = pd.DataFrame(df)
                    df['Step'] = 'Carbocation Homolytic Cleavage'
                    self.data = pd.concat([self.data,df])

                df = self.HeterocyclicCleavageLayer(depth)
                if df['Carbocation'] != []:
                    df = pd.DataFrame(df)
                    df['Step'] = 'Carbocation Heterocyclic Cleavage'
                    self.data = pd.concat([self.data,df])

                df = self.RingFormation(depth)
                if df['Carbocation'] != []:
                    df = pd.DataFrame(df)
                    df['Step'] = 'Ring Formation'
                    self.data = pd.concat([self.data,df])

                df = self.CombineRadicaltoCarbocation(depth)
                if df['Carbocation'] != []:
                    df = pd.DataFrame(df)
                    df['Step'] = 'Radical Carbocation Recombination'
                    self.data = pd.concat([self.data,df])
                depth += 1

                delta = len(self.data.groupby('Hash_Carbocation').min()) - oldval
                self.globaldata['uniques'] += [len(self.data.groupby('Hash_Carbocation').min())]
                self.globaldata['reactions'] = [len(self.data)]


    def MolecularIon(self):
        self.molecularions = GetMolecularIon(self.molecule)

    def InitializeMapping(self):
        self.molecule = Chem.MolFromSmiles(self.smiles)
        self.molecule = Chem.AddHs(self.molecule)
        [atom.SetAtomMapNum(i+1) for i,atom in enumerate(self.molecule.GetAtoms())]
        self.molecule = Chem.MolToSmiles(self.molecule)
        self.atom_mapped_smiles = deepcopy(self.molecule)
        self.molecule = yp.yarpecule(self.molecule,canon=False,mapping=True)


    def Depth1Alkane(self):
        if isinstance(self.molecule,'yarp.yarpecule.yarpecule'):
            d1 = list(set([ y for y in yp.break_bonds([self.molecule],n=1)]))
            asmi = to_smi([self.molecule],label_ind=True)[0]
        else:
            d1 = list(set([ y for y in yp.break_bonds(self.molecule,n=1)]))
            asmi = to_smi(self.molecule,label_ind=True)[0]
        frags = frag_rxn_single_bonds(d1,label_ind=True)
        
        data = dict()
        data['Carbocation'] = []
        data['Radical'] = []
        data['Hash'] = []
        data['Hash_Carbocation'] = []
        data['InChI_Carbocation'] = []
        data['BondMatrix'] = []
        data['FC'] = []
        data['Rads'] = []

        for fragrxn in frags:
            #Check their smiles
            smiles = Chem.MolToSmiles(fragrxn)
            mol = deepcopy(fragrxn)
            mol = RemoveMapping(mol)
            hashe = Chem.MolToSmiles(mol)
            if hashe not in data['Hash']:
                data['Hash'] += [hashe]
                data['Hash_Carbocation'] += [getcarbocationfromhash(hashe)]
                data['InChI_Carbocation'] += [Chem.MoltoInchiKey(Chem.MolFromSmiles(getcarbocationfromhash(hashe)))]
                # Only look at ones with a heavy atom cation
                frags = smiles.split('.')
                for _ in frags:
                    if '+' in _:data['Carbocation'] += [_]
                    else: data['Radical'] += [_]
            
                cule = yp.yarpecule(hashe,canon=False,mapping=True)
                data['BondMatrix'] += [cule.bond_mats[0]]
                data['FC'] += [cule.fc]
                data['Rads'] += [getradicals(cule.bond_mats[0],False)]
                

        data['Depth'] = [1] * len(self.data['Carbocation'])
        data['Reaction'] = [_ for _ in range(len(self.data['Carbocation']))]
        data['Reactant'] = [self.atom_mapped_smiles] * len(self.data['Carbocation'])
        data['Start'] = [self.atom_mapped_smiles] * len(self.data['Carbocation'])
        
        return data 


    def HomolyticCleavageLayer(self,depth=1):
        cations = self.data[self.data.Depth == (depth-1)].Carbocation.tolist()
        radical = self.data[self.data.Depth == (depth-1)].Radical.tolist()

        data = dict()
        data['Carbocation'] = []
        data['Radical'] = []
        data['Hash'] = []
        data['Hash_Carbocation'] = []
        data['InChI_Carbocation'] = []
        data['Reactant'] = []
        data['Start'] = []
        data['Depth'] = []
        data['Reaction'] = []
        data['BondMatrix'] = []
        data['FC'] = []
        data['Rads'] = []
        
        

        for index,ion in enumerate(cations):
            a = yp.yarpecule(ion,canon=False,mapping=True)
            if isinstance(a,'yarp.yarpecule.yarpecule'):
                smi = to_smi([a],label_ind=True)
            else:
                smi = to_smi(a,label_ind=True)
                
            elements = a.elements
            formal_charges = a.fc
            l = 0
            for index1,smiles in enumerate(smi):
                bmat = a.bond_mats[index1]
                rads = getradicals(a.bond_mats[index1],False)
            
                for i in range(bmat.shape[0]):
                    for j in range(bmat.shape[0]):

                        if i != j: # Check if i == j

                            if bmat[i][j] >= 1 and bmat[i][j] <= 2:
                                bond_matrix,_ = homolytic_cleavage(bmat,i,j,rads) 
                                radical_electrons = getradicals(bond_matrix,False)

                                # Create the RDKit Mol object
                                product = Chem.MolToSmiles(create_mol(elements, bond_matrix, formal_charges, radical_electrons,a.amapping))
                                hashe = Chem.MolToSmiles(create_mol(elements, bond_matrix, formal_charges, radical_electrons))
                                
                                if hashe not in data['Hash']: 
                                    data['Hash'] += [hashe]
                                    comps = product.split('.')
                                    for _ in comps:
                                        if '+' in _: 
                                            data['Carbocation'] += [_]

                                            _hash = Chem.MolToSmiles(RemoveMapping(Chem.MolFromSmiles(_)))
                                            _inchi = Chem.MolToInchiKey(RemoveMapping(Chem.MolFromSmiles(_)))

                                            data['Hash_Carbocation'] += [_hash]
                                            data['InChI_Carbocation'] += [_inchi]
                                        else: 
                                            if depth == 1:
                                                data['Radical'] += [_]
                                            else:
                                                data['Radical'] += [radical[index]+'.'+_]
                                    
                                    data['BondMatrix'] += [bond_matrix]
                                    data['FC'] += [formal_charges]
                                    data['Rads'] += [_]
                                    data['Reactant'] += [smiles]
                                    data['Reaction'] += [l]
                                    data['Depth'] += [depth]                                   
                                    l += 1
            
            data['Start'] = [self.atom_mapped_smiles] * len(data['Carbocation'])

                
    def HeterocyclicCleavageLayer(self,depth=1):
        cations = self.data[self.data.Depth == (depth-1)].Carbocation.tolist()
        radical = self.data[self.data.Depth == (depth-1)].Radical.tolist()

        data = dict()
        data['Carbocation'] = []
        data['Radical'] = []
        data['Hash'] = []
        data['Hash_Carbocation'] = []
        data['InChI_Carbocation'] = []
        data['Reactant'] = []
        data['Start'] = []
        data['Depth'] = []
        data['Reaction'] = []
        data['BondMatrix'] = []
        data['FC'] = []
        data['Rads'] = []
        

        for index,ion in enumerate(cations):
            a = yp.yarpecule(ion,canon=False,mapping=True)
            if isinstance(a,'yarp.yarpecule.yarpecule'):
                smi = to_smi([a],label_ind=True)
            else:
                smi = to_smi(a,label_ind=True)
                
            elements = a.elements
            formal_charges = a.fc
            l = 0
            for index1,smiles in enumerate(smi):
                bmat = a.bond_mats[index1]
                elements = a.elements
                formal_charges = a.fc
                for i in range(bmat.shape[0]):
                    for j in range(bmat.shape[0]):
                        if i != j: # Check if i == j
                            if bmat[i][j] == 1:
                                bond_matrix,fc1,fc2 = heterolytic_cleavage(bmat,i,j,formal_charges) 
                                radical_electrons = getradicals(bond_matrix,False)
                                # Create the RDKit Mol object

                                for fc in [fc1,fc2]:
                                    product = Chem.MolToSmiles(create_mol(elements, bond_matrix, fc, radical_electrons,a.amapping))
                                    hashe = Chem.MolToSmiles(create_mol(elements, bond_matrix, fc, radical_electrons))
                                    if hashe not in data['Hash']: 
                                        data['Hash'] += [hashe]
                                        comps = product.split('.')
                                        rs = []
                                        hasion = []
                                        for _ in comps:
                                            count_plus = _.count('+')
                                            count_minus = _.count('-')
                                            if count_plus == 1 and count_minus == 0:
                                                c = _
                                                hasion += [True]
                                            
                                            else:
                                                rs += [_]
                                                hasion += [False]
                                        if True in hasion:
                                            data['Carbocation'] += [c]
                                            _hash = Chem.MolToSmiles(RemoveMapping(Chem.MolFromSmiles(c)))
                                            _inchi = Chem.MolToInchiKey(RemoveMapping(Chem.MolFromSmiles(c)))

                                            data['Hash_Carbocation'] += [_hash]
                                            data['InChI_Carbocation'] += [_inchi]

                                            if depth == 1:
                                                data['Radical'] += [_]
                                            else:
                                                data['Radical'] += [radical[index]+'.'+rs[0]]
                                            
                                            data['BondMatrix'] += [bond_matrix]
                                            data['FC'] += [fc]
                                            data['Rads'] += [radical_electrons]   
                                            data['Reactant'] += [smiles]
                                            data['Reaction'] += [l]
                                            data['Depth'] += [depth]  
                                            
                                            l += 1
        data['Start'] = [self.atom_mapped_smiles] * len(data['Carbocation'])
                                        
                                
    def CombineRadicaltoCarbocation(self,depth=1):
        cations = self.data[self.data.Depth == (depth-1)].Carbocation.tolist()
        radical = self.data[self.data.Depth == (depth-1)].Radical.tolist()

        data = dict()
        data['Carbocation'] = []
        data['Radical'] = []
        data['Hash'] = []
        data['Hash_Carbocation'] = []
        data['InChI_Carbocation'] = []
        data['Reactant'] = []
        data['Start'] = []
        data['Depth'] = []
        data['Reaction'] = []
        data['BondMatrix'] = []
        data['FC'] = []
        data['Rads'] = []

        for index,ion in enumerate(cations):
            availablerads = radical[index].split('.')
            
            for j,r in enumerate(availablerads):
                focus = ion +'.' + r
                availableradscopy = deepcopy(availablerads)
                del availableradscopy[j]
                
                if len(availableradscopy) == 1:
                    radtolook = availableradscopy[0]
                else:
                    string = ''
                    for _ in availableradscopy: string += _ +'.'
                    radtolook = string[:-1]
                
                a = yp.yarpecule(focus,canon=False,mapping=True)
                mappings = a.amapping
                
     
                if isinstance(a,'yarp.yarpecule.yarpecule'):
                    cules = [ y for y in yp.form_bonds([a]) ]
                else:
                    cules = [ y for y in yp.form_bonds(a) ]
                for cule in cules:
                
                    mols = to_mol([cule],label_ind=True)
                    for index,mol in enumerate(mols):
                        bond_matrix = cule.bond_mats[index]
                        formal_charges = cule.fc
                        radical_electrons = getradicals(cule.bond_mats[index],False)
                        mol = EditAtomMapping(mol,mappings)
                        product = Chem.MolToSmiles(mol)
                        hashe = Chem.MolToSmiles(RemoveMapping(mol))
                        if hashe not in data['Hash']: 
                            data['Hash'] += [hashe]
                            comps = product.split('.')
                            for _ in comps:
                                if '+' in _: 
                                    data['Carbocation'] += [_]
                                    _hash = Chem.MolToSmiles(RemoveMapping(Chem.MolFromSmiles(_)))
                                    _inchi = Chem.MolToInchiKey(RemoveMapping(Chem.MolFromSmiles(_)))

                                    data['Hash_Carbocation'] += [_hash]
                                    data['InChI_Carbocation'] += [_inchi]

                            data['Radical'] += [radtolook]
                            data['Reactant'] += [ion]
                            data['BondMatrix'] += [bond_matrix]
                            data['FC'] += [formal_charges]
                            data['Rads'] += [radical_electrons]
                            

                            data['Reaction'] += [l]
                            data['Depth'] += [depth]  
                            l += 1
                k += 1
   
    def RingFormation(self,depth=1):
        cations = self.data[self.data.Depth == (depth-1)].Carbocation.tolist()
        radical = self.data[self.data.Depth == (depth-1)].Radical.tolist()

        data = dict()
        data['Carbocation'] = []
        data['Radical'] = []
        data['Hash'] = []
        data['Hash_Carbocation'] = []
        data['InChI_Carbocation'] = []
        data['Reactant'] = []
        data['Start'] = []
        data['Depth'] = []
        data['Reaction'] = []
        data['BondMatrix'] = []
        data['FC'] = []
        data['Rads'] = []
        
        

        for index,ion in enumerate(cations):
            a = yp.yarpecule(ion,canon=False,mapping=True)
            if isinstance(a,'yarp.yarpecule.yarpecule'):
                smi = to_smi([a],label_ind=True)
            else:
                smi = to_smi(a,label_ind=True)
                
            elements = a.elements
            formal_charges = a.fc
            l = 0
            for index1,smiles in enumerate(smi):
                bmat = a.bond_mats[index1]
                rads = getradicals(a.bond_mats[index1],False)

                possibleconnectpoints = np.where(np.array(rads) % 2 == 1)

                for i in possibleconnectpoints:
                    for j in possibleconnectpoints:
                        if i != j:
                            bond_matrix,radical_electrons = makebondbetweentworadicals(bmat,i,j,rads)
                            # Create the RDKit Mol object
                            product = Chem.MolToSmiles(create_mol(elements, bond_matrix, formal_charges, radical_electrons,a.amapping))
                            hashe = Chem.MolToSmiles(create_mol(elements, bond_matrix, formal_charges, radical_electrons))
                            
                            if hashe not in data['Hash']: 
                                data['Hash'] += [hashe]
                                comps = product.split('.')
                                for _ in comps:
                                    if '+' in _: data['Carbocation'] += [_]
                                    else: 
                                        if depth == 1:
                                            data['Radical'] += [_]
                                        else:
                                            data['Radical'] += [radical[index]+'.'+_]
                                data['Reactant'] += [smiles]
                                data['Reaction'] += [l]
                                data['Depth'] += [depth]                                   
                                l += 1
